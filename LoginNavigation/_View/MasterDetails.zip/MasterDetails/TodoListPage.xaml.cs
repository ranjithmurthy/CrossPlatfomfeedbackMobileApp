﻿using Xamarin.Forms;

namespace LoginNavigation
{
	public partial class TodoListPage : ContentPage
	{
		public TodoListPage ()
		{
			InitializeComponent ();
		}
	}
}

