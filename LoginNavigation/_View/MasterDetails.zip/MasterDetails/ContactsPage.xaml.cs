﻿using Xamarin.Forms;

namespace LoginNavigation
{
	public partial class ContactsPage : ContentPage
	{
		public ContactsPage ()
		{
			InitializeComponent ();
		}
	}
}

