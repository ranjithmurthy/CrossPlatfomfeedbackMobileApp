﻿using Xamarin.Forms;

namespace LoginNavigation
{
	public partial class ReminderPage : ContentPage
	{
		public ReminderPage ()
		{
			InitializeComponent();
		}
	}
}

